# trial.text
my trial file
okwero is a great guy, only needs to focus and keep disciplined
All gentlement need to focus on God to know from whom their purpose is and to whom we all return
