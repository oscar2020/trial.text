package classPerson;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

       int table[][] = new int [3][4];
        for (int i=0;i<3;i++) {
        	
        	for (int j=0;j<4;j++) {
        		
        		System.out.println(table[i][j]);
        	}
        

// all good boys deserve favor always
	
        }
		
	}

}
